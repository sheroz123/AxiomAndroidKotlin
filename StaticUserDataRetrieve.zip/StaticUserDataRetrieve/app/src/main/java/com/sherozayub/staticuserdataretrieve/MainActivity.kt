package com.sherozayub.staticuserdataretrieve

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.sherozayub.staticuserdataretrieve.Model.User

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var id = findViewById<TextView>(R.id.userID)
        var name = findViewById<TextView>(R.id.userName)
        var age = findViewById<TextView>(R.id.userAge)
        var email = findViewById<TextView>(R.id.userEmail)


        var previuse = findViewById<Button>(R.id.previousBtn)
        var next = findViewById<Button>(R.id.nextBtn)

        var myUserList : ArrayList<User> = ArrayList()

        var user0 = User("0", "0", "0@gmail.com")
        var user1 = User("Name1", "11", "name1@gmail.com")
        var user2 = User("Name2", "12", "name2@gmail.com")
        var user3 = User("Name3", "13", "name3@gmail.com")
        var user4 = User("Name4", "14", "name4@gmail.com")
        var user5 = User("Name5", "15", "name5@gmail.com")

        myUserList.add(user0)
        myUserList.add(user1)
        myUserList.add(user2)
        myUserList.add(user3)
        myUserList.add(user4)
        myUserList.add(user5)

        var count : Int = 0

        id.setText(""+ 0)
        name.setText(user0.name)
        age.setText(user0.age)
        email.setText(user0.email)


        next.setOnClickListener {
            if (count +1 >= myUserList.size)
            {
                Toast.makeText(this,"No more Data User", Toast.LENGTH_SHORT).show()
            }
            else
            {
                count++
                id.setText("" + count)
                name.setText(myUserList.get(count).name)
                age.setText(myUserList.get(count).age)
                email.setText(myUserList.get(count).email)

            }
        }
        previuse.setOnClickListener {
            if (count -1 < 0)
            {
                Toast.makeText(this,"No Previuse Data User", Toast.LENGTH_SHORT).show()
            }
            else
            {
                count--
                id.setText("" + count)
                name.setText(myUserList.get(count).name)
                age.setText(myUserList.get(count).age)
                email.setText(myUserList.get(count).email)

            }
        }
    }
}
