package com.sherozayub.staticuserdataretrieve.Model

class User(var name : String,var age : String, var email : String) {
}