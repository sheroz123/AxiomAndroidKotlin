package com.sherozayub.newintent

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class AgeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_age)

        var myIntent = intent
        var myNewAge = myIntent.getStringExtra("Age")
        var myAge = findViewById<TextView>(R.id.myUpdateAge)
        myAge.text = "My Age is:: $myNewAge"




    }
}
