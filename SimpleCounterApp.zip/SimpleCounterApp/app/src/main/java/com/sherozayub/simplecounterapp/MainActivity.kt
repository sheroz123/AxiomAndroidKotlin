package com.sherozayub.simplecounterapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var score : TextView = findViewById(R.id.tvScore)
        var increment : Button = findViewById(R.id.btIncrement)
        var dicrement : Button = findViewById(R.id.btDicrement)
        var reset : Button = findViewById(R.id.btReset)


        var counter : Int = 0

        increment.setOnClickListener {
            score.setText("" + ++counter)
        }

        dicrement.setOnClickListener {
            if(counter > 0)
            {
                score.setText("" + --counter)
            }

            else{
                Toast.makeText(this, " Cant Go to Less than 0 Value", Toast.LENGTH_SHORT).show()
            }
        }

        reset.setOnClickListener {
            var resetValue :Int= 0
            tvScore.setText("" + resetValue)

        }
    }
}
